from django.contrib import admin
from django.urls import path
from home import views

urlpatterns = [
    path("", views.index, name='home'),
    path("books", views.books, name='books'),
    path("action", views.action, name='action'),
    path("computers", views.computers, name='computers'),
    path("science", views.science, name='science'),
    path("romance", views.romance, name='romance'),
    path("about", views.about, name='about'),
    path("contacts", views.contacts, name='contacts'),
    path('login',views.loginUser,name="login"),
    path('logout',views.logoutUser,name="logout"),
    path('items',views.items,name="items"),
    path('cart',views.cart,name="cart")
]