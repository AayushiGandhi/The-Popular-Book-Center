from django.shortcuts import render, HttpResponse, redirect
from datetime import datetime
from home.models import Contacts, Cart
from django.contrib import messages
from django.contrib.auth import logout, authenticate, login
from .models import Product
from math import ceil


# Create your views here.
def index(request):
    #return render(request, 'index.html')
    if request.user.is_anonymous:
        return render(request,'index.html')
    else:
        return render(request,'loggedin.html')
    #return HttpResponse("this is homepage")

def books(request):
    print(request)
    products = Product.objects.all()
    print(products)
    n = len(products)
    no_of_slides = n//4 + ceil((n/4) - (n//4))
    params = {'no_of_slides':no_of_slides, 'range':range(1,no_of_slides), 'product':products}
    return render(request, 'books.html', params)

def action(request):
    allProds=[]
    catprods = Product.objects.values('category','id')
    cats1 = {item['category'] for item in catprods}
    for i in cats1:
        if i == 'Action':
            cats=i
    print(cats)
    products = Product.objects.filter(category=cats)
    print(products)

    #for cat in cats:
    #    product = Product.objects.filter(category=cat)
    n = len(products)
    no_of_slides = n//4 + ceil((n/4) - (n//4))
    params = {'no_of_slides':no_of_slides, 'range':range(1,no_of_slides), 'product':products}
    #allProds.append([product, range(1, no_of_slides), no_of_slides])
    #params = {'allProds':allProds}

    return render(request,'action.html',params)

def computers(request):
    allProds=[]
    catprods = Product.objects.values('category','id')
    cats1 = {item['category'] for item in catprods}
    for i in cats1:
        if i == 'Computers':
            cats=i
    print(cats)
    products = Product.objects.filter(category=cats)
    print(products)

    n = len(products)
    no_of_slides = n//4 + ceil((n/4) - (n//4))
    params = {'no_of_slides':no_of_slides, 'range':range(1,no_of_slides), 'product':products}

    return render(request,'computers.html',params)

def science(request):
    allProds=[]
    catprods = Product.objects.values('category','id')
    cats1 = {item['category'] for item in catprods}
    for i in cats1:
        if i == 'Science':
            cats=i
    print(cats)
    products = Product.objects.filter(category=cats)
    print(products)

    n = len(products)
    no_of_slides = n//4 + ceil((n/4) - (n//4))
    params = {'no_of_slides':no_of_slides, 'range':range(1,no_of_slides), 'product':products}

    return render(request,'science.html',params)

def romance(request):
    allProds=[]
    catprods = Product.objects.values('category','id')
    cats1 = {item['category'] for item in catprods}
    for i in cats1:
        if i == 'Romance':
            cats=i
    print(cats)
    products = Product.objects.filter(category=cats)
    print(products)

    n = len(products)
    no_of_slides = n//4 + ceil((n/4) - (n//4))
    params = {'no_of_slides':no_of_slides, 'range':range(1,no_of_slides), 'product':products}

    return render(request,'romance.html',params)

def about(request):
    return render(request, 'about.html')
    #return HttpResponse("this is about page")   

def department(request):
    return render(request, 'department.html')
    #return HttpResponse("this is services page")

def cart(request):
    if request.method == "POST":
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        username = request.POST.get('username')
        email = request.POST.get('email')
        country = request.POST.get('country')
        state = request.POST.get('state')
        z = request.POST.get('z')
        paymentmethod = request.POST.get('paymentmethod')
        cardname = request.POST.get('cardname')
        cardnumber = request.POST.get('cardnumber')
        exp = request.POST.get('exp')
        cvv = request.POST.get('cvv')
        cart = Cart(firstname=firstname, lastname=lastname, username=username, email=email, country=country, state=state, z=z, paymentmethod=paymentmethod, cardname=cardname, cardnumber=cardnumber, exp=exp, cvv=cvv, date=datetime.today())
        cart.save()
        messages.success(request, 'Payment successful!')

    return render(request, 'cart.html')

def items(request):
    return render(request, 'items.html')

def contacts(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contacts = Contacts(name=name, email=email, phone=phone, desc=desc, date=datetime.today())
        contacts.save()
        messages.success(request, 'Query submitted successfully!')
        
    return render(request, 'contacts.html')
    #return HttpResponse("this is contacts page") 


def loginUser(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        #print(username,password)
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request,user)
            return render(request,'loggedin.html')
        else:
            return render(request,'login.html')
    return render(request,'login.html')

def logoutUser(request):
    logout(request)
    return render(request,'index.html')
