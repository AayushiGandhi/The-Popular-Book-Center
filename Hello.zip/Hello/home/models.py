from django.db import models
import datetime

# Create your models here.
class Contacts(models.Model):
    name = models.CharField(max_length=122)
    email = models.CharField(max_length=122)
    phone = models.CharField(max_length=12)
    desc = models.TextField()
    date = models.DateField()

    def __str__(self):
        return self.name
    
class Cart(models.Model):
    firstname = models.CharField(max_length=122)
    lastname = models.CharField(max_length=122)
    username = models.CharField(max_length=122)
    email = models.EmailField(max_length=122)
    country = models.CharField(max_length=122, default="")
    state = models.CharField(max_length=122, default="")
    z = models.CharField(max_length=122)
    paymentmethod = models.CharField(max_length=122, default="")
    cardname = models.CharField(max_length=122)
    cardnumber = models.IntegerField()
    exp = models.CharField(max_length=122, default="")
    cvv = models.IntegerField()

    date = models.DateField()

    def __str__(self):
        return self.firstname

class Product(models.Model):
    id = models.AutoField
    product_name = models.CharField(max_length=122)
    category = models.CharField(max_length=122, default="")
    price = models.IntegerField(default=0)
    product_desc = models.CharField(max_length=300)
    image = models.ImageField(upload_to = "home\images", default="")
    pub_date = models.DateField()

    def __str__(self):
        return self.product_name
