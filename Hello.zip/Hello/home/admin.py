from django.contrib import admin
from home.models import Contacts
from home.models import Cart
from home.models import Product

# Register your models here.
admin.site.register(Contacts)
admin.site.register(Cart)
admin.site.register(Product)
